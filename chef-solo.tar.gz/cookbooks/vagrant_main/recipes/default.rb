require_recipe "apt"
require_recipe "bundler"
require_recipe "gems"
require_recipe "nginx"
require_recipe "unicorn"
require_recipe "ruby"
require_recipe "build-essential"
require_recipe "sqlite"


