default[:gem_server][:rf_virtual_host_name]  = "rubyforge.#{domain}"
default[:gem_server][:rf_virtual_host_alias] = "rubyforge"
default[:gem_server][:rf_directory]          = "/srv/rubyforge"
