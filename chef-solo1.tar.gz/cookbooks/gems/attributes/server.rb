default[:gem_server][:virtual_host_name]  = "gems.#{domain}"
default[:gem_server][:virtual_host_alias] = "gems"
default[:gem_server][:directory]          = "/srv/gems"
