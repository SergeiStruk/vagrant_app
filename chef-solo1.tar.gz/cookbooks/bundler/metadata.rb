maintainer        "37signals"
maintainer_email  "sysadmins@37signals.com"
description       "Configures gem bundler"
version           "0.1"
